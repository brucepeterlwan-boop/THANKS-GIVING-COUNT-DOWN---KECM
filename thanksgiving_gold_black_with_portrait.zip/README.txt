THANKSGIVING SINGLE-PAGE WEBSITE
Event: Sunday, 29 November 2026 (East Africa Time, UTC+3)

The supplied portrait is included as portrait.jpg. Keep it in the same folder as index.html.
The countdown updates every second. The percentage is the elapsed portion of the 17 days immediately before the event date.

Deploy by extracting this ZIP and uploading the folder contents to Netlify.
